-- Contact [ent4]
alter table `contact`  add column  `linkedin`  varchar(255);
alter table `contact`  add column  `github`  varchar(255);


